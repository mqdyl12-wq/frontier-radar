# 前沿雷达：自动更新部署包（v1.1）

这个版本沿用原来的网页 UI，并增加 **GitHub Actions 定时采集 → 提交 JSON → GitHub Pages 发布 → 网页读取数据** 的完整技术链。运行前需要上传到你自己的 GitHub 仓库；这里不能代替你授权并部署到你的账号。

## 1. 五分钟了解结构

- `index.html`：已有的前沿雷达 UI。首次打开时读取 `./data/feed.json`，合并到浏览器本地资料。即使同步失败也不会清空本地收藏。
- `scripts/update_feed.py`：Python 标准库实现的自动采集与去重；来源为 Crossref、arXiv、OpenAI 官方 RSS、Google DeepMind 官方 RSS。
- `.github/workflows/update-and-deploy.yml`：自动采集并发布网页；支持手动运行。
- `data/feed.json`：公开的结构化数据源，首次部署时是空列表。首个工作流成功运行后填入数据。
- `supabase/personal_reading.sql`：未来配置**跨设备个人收藏与笔记**时的数据库结构及访问控制。当前网页仍使用浏览器 localStorage，未自动连接 Supabase。

## 2. 上线步骤（只需要操作一次）

1. 在 https://github.com/ 新建仓库，如 `frontier-radar`。建议先使用公开仓库，并注意这意味着网页和公开信息源数据人人可以访问；**不要上传任何私人研究手稿、笔记或密钥**。
2. 将此目录**全部内容**上传到仓库根目录，包含隐藏的 `.github/workflows/` 文件夹。用 Git 命令推送最稳妥：
   ```bash
   git init
   git add .
   git commit -m "Initial frontier radar"
   git branch -M main
   git remote add origin https://github.com/<你的用户名>/frontier-radar.git
   git push -u origin main
   ```
3. 仓库 → Settings → Actions → General → Workflow permissions → 确认 `GITHUB_TOKEN` 对仓库具有写入权限。若组织策略限制写权限，需管理员授权；不要在仓库中硬编码 token。
4. 仓库 → Settings → Pages → Build and deployment → Source 选 **GitHub Actions**。
5. 仓库 → Actions → 选择 **Update frontier radar** → **Run workflow**，检查运行日志。
6. 工作流成功后，前往仓库 Settings → Pages 获取页面地址，一般为 `https://<用户名>.github.io/frontier-radar/`。这是示例路径，实际以 GitHub 显示为准。
7. 此后每天上午 **08:17（北京时间）** 自动运行，并重新发布页面；定时可能因 GitHub 队列延迟，通常不保证秒级准时。日程文件在 `.github/workflows/update-and-deploy.yml` 中修改。

> 该采集任务与 ChatGPT 已设置的日报自动化是 **两套独立流程**。ChatGPT 的日报不会自动写入这个 GitHub 仓库；如需把 ChatGPT 深度解读送入网站，需要增加另一个有权限的导出/写入接口。

## 3. 信息质量分级（重要）

当前 v1.1 自动采集的目标是**可靠收集候选资料**，而不是凭标题生成论文方法和结论：

- Crossref：根据元数据首次登记日期找新文献，记录出版日期与登记日期；仅标题同时命中 AI 与传播/信息关键词才收录。若来源未提供摘要，明确说明“未提供摘要”。
- arXiv：标明预印本性质，保留首次发布日期与修订日期，并只摘录作者摘要；不宣称已通过同行评审。
- OpenAI/DeepMind：只读取官方 RSS 标题、发布时间、链接及可用摘要，不推断实际技术效果。
- “是否涉及公共讨论”默认 `false`，代表“尚未人工确认是否直接研究公共讨论”，**不是确认该论文不涉及公共讨论**。要准确赋值需要人工/进一步模型核查。
- “研究机会”不会自动生成。你可以在网页继续导入经过核查的研究线索，或以后增加 AI 分析服务。
- 由于访问失败、搜索范围、索引滞后和免费 API 限制，不能保证覆盖“全网所有新成果”；定时数据源失败时保留上一版数据，并在 GitHub Actions 中记录错误。
- `data/feed.json` 目前最多保留 950 条文献与 950 条技术动态，超出容量要升级到真正的数据库与分页接口。Git 历史保留以前版本，但不等于全文可检索的无限历史库。

## 4. 需要真正的“每天中文深度简报”时

建议在当前自动采集后增加一道独立流程：从新候选中选出高相关内容 → 检索论文摘要与原文、核对 DOI/发表状态/关键论断 → 用 LLM 生成中文摘要、研究方法、理论相关性与研究机会 → 质量规则检查（关键字段必须有证据来源）→ 发布到 `data/feed.json`。使用模型 API 时需要提供服务商的 API Key，**仅放 GitHub Actions Secrets，不写进网页 JS、公开 JSON 或仓库**。若全文不可访问，必须只写来源摘要；模型生成的推论需标注。

实际用户需要的“概览 3 项 + 论文 5–8 篇 + 技术动态 + 研究机会”属于这一增强流程，单靠 RSS 和 Crossref 元数据无法等价实现。

## 5. 个人文献数据库（第二阶段）

当前阅读笔记仍在浏览器 localStorage，不会跨设备同步。若需要电脑、手机同一账号同步：

1. 注册并创建一个 Supabase 项目，开启电子邮箱登录（Supabase Auth）。
2. 在 Supabase SQL Editor 执行 `supabase/personal_reading.sql`，得到 `reading_notes` 表，并启用按登录用户隔离数据的 RLS。
3. 给网页增加 Supabase Auth 登录表单；登录后从 `reading_notes` 拉取、保存个人条目。首次登录应把浏览器已有笔记一次性迁移，以免遗失。
4. 注意：前端只允许使用 Supabase **publishable/anon key**，真正的 secret/service role key 必须只存于后端。部署前应测试未登录用户、本人、其他用户的增删改查权限。

`supabase/personal_reading.sql` 是供接入用的迁移模板，**尚未在实际 Supabase 项目中运行和验证**。

## 6. 本地验证

不联网的 Python 采集逻辑测试：

```bash
python -m unittest discover -s tests -v
```

JavaScript 语法检查可将 `index.html` 的 `<script>` 内容提取后使用 `node --check`。已对浏览器执行模拟数据源的自动同步、文献列表和阅读记录交互测试；但尚未在真实 GitHub Pages 和真实 Supabase 项目上部署验证，在线检索源端点未来可能变化。

## 7. 官方参考

- GitHub Actions cron：https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-syntax#onschedule
- GitHub Pages：https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
- Crossref：https://www.crossref.org/documentation/retrieve-metadata/rest-api/rest-api-filters/
- arXiv：https://info.arxiv.org/help/api/user-manual.html
- Supabase RLS：https://supabase.com/docs/guides/database/postgres/row-level-security
