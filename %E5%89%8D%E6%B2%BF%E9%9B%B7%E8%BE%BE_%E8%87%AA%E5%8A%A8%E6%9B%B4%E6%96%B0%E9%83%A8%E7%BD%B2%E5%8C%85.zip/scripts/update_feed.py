#!/usr/bin/env python3
"""Collect verifiable *metadata* from academic APIs and official RSS feeds.

No LLM, no fabricated methods/results. Network calls are made at runtime by
GitHub Actions; offline tests use fixtures. Standard library only.
"""
from __future__ import annotations

import hashlib
import html
import json
import os
import re
import sys
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "data" / "feed.json"
AT = "{http://www.w3.org/2005/Atom}"
KEYWORDS = re.compile(r"\b(?:AI[- ]mediated|AIGC|generative AI|large language model|LLMs?|chatbot|algorithmic|artificial intelligence|AI summar(?:y|ies|ization)|AI overviews?|generative search|GPT[- 0-9]|news summarization)\b", re.I)
CONTEXT = re.compile(r"\b(?:communicat|social media|politic|public|news|journalis|discourse|discussion|opinion|emotion|information|search|summari|media|trust|normative|online|participat|interperson|credibil|platform)\w*", re.I)
TERMS = [
    "AI-mediated communication", "AI summaries public discussion",
    "generative AI social media", "AI information summarization",
    "generative search opinion", "algorithmic gatekeeping news",
]
OFFICIAL_RSS = [
    ("OpenAI 官方动态", "https://openai.com/news/rss.xml", "openai.com"),
    ("Google DeepMind 官方博客", "https://deepmind.google/blog/rss.xml", "deepmind.google"),
]


def clean(s: str, limit: int = 360) -> str:
    s = re.sub(r"<[^>]*>", " ", str(s or ""))
    s = re.sub(r"\s+", " ", html.unescape(s)).strip()
    return s[:limit] + ("…" if len(s) > limit else "")


def key(url: str) -> str:
    doi = re.search(r"(?:doi\.org/|doi:)(10\.\d{4,9}/[^\s?#]+)", url, re.I)
    canonical = ("doi:" + doi.group(1).lower().rstrip("/")) if doi else url.strip().lower().rstrip("/")
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:18]


def url_open(url: str) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "FrontierRadar/1.1 (academic metadata aggregator)", "Accept": "application/xml,application/json,text/xml,*/*"})
    with urllib.request.urlopen(req, timeout=25) as resp:
        return resp.read(2_500_000)


def fetch_crossref(since: str) -> list[dict]:
    collected = []
    successful_requests = 0
    for term in TERMS:
        args = urllib.parse.urlencode({
            "query.bibliographic": term,
            "filter": f"from-created-date:{since}",
            "sort": "updated", "order": "desc", "rows": 30,
        })
        url = "https://api.crossref.org/works?" + args
        try:
            items = json.loads(url_open(url))["message"]["items"]
            successful_requests += 1
        except Exception as ex:
            print(f"WARNING Crossref {term}: {ex}", file=sys.stderr)
            continue
        for item in items:
            title = clean((item.get("title") or [""])[0], 240)
            if not (KEYWORDS.search(title) and CONTEXT.search(title)):
                continue
            doi = item.get("DOI")
            if not doi:
                continue
            published = item.get("published-online") or item.get("published") or item.get("issued") or {}
            parts = (published.get("date-parts") or [[]])[0]
            publication = "-".join([str(parts[0])] + [f"{p:02d}" for p in parts[1:]]) if parts else "未知"
            created = item.get("created", {}).get("date-time", "")[:10]
            author = ", ".join([" ".join(filter(None, [a.get("given", ""), a.get("family", "")])) for a in item.get("author", [])[:6]])
            source = ", ".join(item.get("container-title", [])[:1]) or "Crossref 登记记录"
            link = "https://doi.org/" + doi
            abstract = clean(item.get("abstract", ""))
            collected.append({
                "id": "p-" + key(link), "title": title, "en": title, "authors": author or "作者未提供",
                "date": publication, "discoveredAt": created, "venue": source,
                "type": "工作论文" if item.get("type") == "posted-content" else "正式发表",
                "topic": ["AI摘要"] if re.search(r"summar|overview|search", title, re.I) else ["AI-MC"],
                "public": False, "method": "待阅读全文核查，不能从题录判定研究方法。",
                "question": "自动发现的新文献；研究问题需阅读摘要或全文确定。",
                "finding": ("来源提供的摘要摘录（未经人工核查）：" + abstract if abstract else "自动获取题录，来源未提供可核对的摘要；不推断研究发现。"),
                "scope": f"自动检索 Crossref 题录（登记日期 {created or '未明'}，出版日期 {publication}）；未核对全文。",
                "significance": "题名与关注方向相关；是否研究公共讨论或集体表达尚未人工判定。",
                "tags": ["自动收录", "待精读", "Crossref"], "url": link,
            })
    if successful_requests == 0:
        raise RuntimeError("All Crossref queries failed")
    return unique(collected)


def fetch_arxiv(since: datetime) -> list[dict]:
    query = 'all:"AI-mediated communication" OR all:"social media summarization" OR all:"generative search" OR all:"AI Overviews" OR all:"opinion climate"'
    args = urllib.parse.urlencode({"search_query": query, "start": 0, "max_results": 100, "sortBy": "submittedDate", "sortOrder": "descending"})
    root = ET.fromstring(url_open("https://export.arxiv.org/api/query?" + args))
    out = []
    for e in root.findall(f"{AT}entry"):
        title = clean(e.findtext(f"{AT}title"), 240)
        abstract = clean(e.findtext(f"{AT}summary"), 380)
        published = e.findtext(f"{AT}published") or ""
        updated = e.findtext(f"{AT}updated") or published
        if not updated or datetime.fromisoformat(updated.replace("Z", "+00:00")) < since:
            continue
        link = e.findtext(f"{AT}id") or ""
        if not link.startswith("http"):
            continue
        authors = ", ".join(clean(a.findtext(f"{AT}name"), 80) for a in e.findall(f"{AT}author")[:6])
        out.append({
            "id": "p-" + key(link), "title": title, "en": title, "authors": authors or "作者未提供",
            "date": published[:10], "updatedAt": updated[:10], "venue": "arXiv（预印本）",
            "type": "工作论文", "topic": ["AI摘要"], "public": False,
            "method": "预印本：研究方法需要核对全文。", "question": "依据题名/摘要筛选；问题需阅读全文确认。",
            "finding": "作者摘要摘录（未经全文核查）：" + abstract,
            "scope": f"自动检索 arXiv；首次发布 {published[:10]}，最新修订 {updated[:10]}；未核对全文。",
            "significance": "与 AI 摘要或 AI 中介传播相关的候选文献；公共讨论属性未人工判定。",
            "tags": ["自动收录", "预印本", "待精读"], "url": link,
        })
    return out


def parse_day(value: str) -> str:
    if not value:
        return ""
    try:
        return parsedate_to_datetime(value).date().isoformat()
    except (TypeError, ValueError):
        return value[:10]


def fetch_rss(source: str, url: str, domain: str, since_day: str) -> list[dict]:
    root = ET.fromstring(url_open(url))
    items = root.findall("./channel/item")
    if not items:  # Atom feed support
        items = root.findall(f"{AT}entry")
    out = []
    for e in items:
        atom = e.tag.endswith("entry")
        name = clean(e.findtext(f"{AT}title" if atom else "title"), 240)
        link = e.findtext("link") if not atom else next((l.get("href") for l in e.findall(f"{AT}link") if l.get("rel") in (None, "alternate")), "")
        link = (link or "").strip()
        parsed = urllib.parse.urlparse(link)
        if parsed.scheme != "https" or (parsed.hostname != domain and not (parsed.hostname or "").endswith("." + domain)):
            continue
        day = parse_day(e.findtext(f"{AT}published" if atom else "pubDate") or e.findtext(f"{AT}updated") or "")
        if day and day < since_day:
            continue
        abstract = clean(e.findtext(f"{AT}summary" if atom else "description"))
        out.append({
            "id": "t-" + key(link), "title": name, "date": day or "日期待核查", "source": source,
            "excerpt": "官方 RSS 摘要（未阅读全文独立核查）：" + (abstract or "请打开官方原文确认具体更新。"),
            "impact": "研究启发待补充；不能从标题推断实际研究影响。",
            "tags": ["自动收录", "官方动态"], "url": link,
        })
    return out


def unique(records: list[dict]) -> list[dict]:
    by = {}
    for r in records:
        by.setdefault(r["id"], r)
    return sorted(by.values(), key=lambda x: x.get("date", ""), reverse=True)


def main():
    now = datetime.now(timezone.utc)
    since = now - timedelta(days=int(os.getenv("LOOKBACK_DAYS", "7")))
    success = 0
    issues = []
    try:
        papers1 = fetch_crossref(since.date().isoformat())
        success += 1
    except Exception as ex:
        papers1 = []; issues.append(f"Crossref: {ex}")
    try:
        papers2 = fetch_arxiv(since)
        success += 1
    except Exception as ex:
        papers2 = []; issues.append(f"arXiv: {ex}")
    tech = []
    for source, url, domain in OFFICIAL_RSS:
        try:
            tech.extend(fetch_rss(source, url, domain, since.date().isoformat()))
            success += 1
        except Exception as ex:
            issues.append(f"{source}: {ex}")
    if success == 0:
        raise RuntimeError("All sources failed; preserving previous published feed")

    previous = json.loads(OUTPUT.read_text(encoding="utf-8")) if OUTPUT.exists() else {}
    papers = unique(previous.get("papers", []) + papers1 + papers2)
    tech = unique(previous.get("tech", []) + tech)
    result = {
        "date": now.date().isoformat(),
        "label": f"自动收录 · 最近一次检索 {now.strftime('%Y-%m-%d %H:%M UTC')}",
        "checkedAt": now.isoformat(),
        "papers": papers[:950], "tech": tech[:950],
        "opportunities": previous.get("opportunities", []),
        "sources": ["Crossref", "arXiv", *[s[0] for s in OFFICIAL_RSS]],
        "issues": issues,
    }
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    tmp = OUTPUT.with_suffix(".tmp")
    tmp.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(OUTPUT)
    print(f"Updated: {len(papers1)+len(papers2)} academic records; {len(tech)} news records; {len(issues)} source warnings")
    for issue in issues:
        print("WARNING", issue, file=sys.stderr)


if __name__ == "__main__":
    main()
