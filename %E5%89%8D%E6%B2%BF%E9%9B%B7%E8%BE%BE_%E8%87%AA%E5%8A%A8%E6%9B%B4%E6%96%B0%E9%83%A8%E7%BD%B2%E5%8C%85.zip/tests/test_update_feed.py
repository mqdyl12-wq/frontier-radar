import importlib.util
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

MODULE_PATH = Path(__file__).resolve().parents[1] / 'scripts' / 'update_feed.py'
spec = importlib.util.spec_from_file_location('update_feed', MODULE_PATH)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

CROSSREF = {
    'message': {'items': [
        {'title': ['AI-mediated communication in social media discussions'],
         'DOI': '10.9999/example', 'created': {'date-time': '2026-11-17T00:00:00Z'},
         'published-online': {'date-parts': [[2026, 11, 17]]},
         'type': 'journal-article', 'author': [{'given': 'A', 'family': 'Author'}],
         'container-title': ['Sample Journal']},
        {'title': ['Unrelated subject'], 'DOI': '10.9999/irrelevant'}
    ]}
}
RSS = b'''<?xml version="1.0"?><rss><channel><item><title>AI Research Announcement</title>
<link>https://openai.com/index/ai-research/</link><description>New release</description>
<pubDate>Tue, 17 Nov 2026 00:00:00 GMT</pubDate></item>
<item><title>Malicious</title><link>https://example.com/no</link>
<pubDate>Tue, 17 Nov 2026 00:00:00 GMT</pubDate></item></channel></rss>'''
ARXIV = b'''<feed xmlns="http://www.w3.org/2005/Atom">
<entry><id>https://arxiv.org/abs/2601.12345</id><title>AI summaries in discussions</title>
<summary>Preprint abstract</summary><published>2026-11-17T00:00:00Z</published>
<updated>2026-11-17T01:00:00Z</updated><author><name>A. Author</name></author></entry></feed>'''

class TestFeed(unittest.TestCase):
    def test_crossref_metadata(self):
        with patch.object(mod, 'url_open', return_value=json.dumps(CROSSREF).encode()):
            items = mod.fetch_crossref('2026-11-16')
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]['type'], '正式发表')
        self.assertFalse(items[0]['public'])
        self.assertIn('未核对全文', items[0]['scope'])
        self.assertIn('10.9999/example', items[0]['url'])

    def test_rss_source_domain_restricted(self):
        with patch.object(mod, 'url_open', return_value=RSS):
            items = mod.fetch_rss('OpenAI', 'https://openai.com/news/rss.xml','openai.com','2026-11-16')
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]['date'], '2026-11-17')

    def test_arxiv_preprint(self):
        from datetime import datetime, timezone
        with patch.object(mod, 'url_open', return_value=ARXIV):
            items=mod.fetch_arxiv(datetime(2026,11,16,tzinfo=timezone.utc))
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]['type'], '工作论文')
        self.assertEqual(items[0]['date'], '2026-11-17')

    def test_dedup_and_persistence(self):
        with tempfile.TemporaryDirectory() as d:
            output=Path(d) / 'feed.json'
            output.write_text(json.dumps({'papers':[{'id':'p-foo','date':'2026-01-01','title':'old','url':'https://doi.org/10.1/a'}],'tech':[],'opportunities':[]}))
            with patch.object(mod,'OUTPUT',output),\
                 patch.object(mod,'fetch_crossref',return_value=[{'id':'p-foo','date':'2026-01-02','title':'new','url':'https://doi.org/10.1/a'}]),\
                 patch.object(mod,'fetch_arxiv',return_value=[]),\
                 patch.object(mod,'fetch_rss',return_value=[]):
                mod.main()
            result=json.loads(output.read_text())
            self.assertEqual(len(result['papers']),1)
            self.assertEqual(result['papers'][0]['title'],'old') # existing curated metadata never overwritten by auto ingestion
            self.assertIn('checkedAt',result)

    def test_failure_does_not_overwrite(self):
        with tempfile.TemporaryDirectory() as d:
            output=Path(d)/'feed.json'
            original='{"papers": [], "tech": [], "opportunities": []}'
            output.write_text(original)
            with patch.object(mod,'OUTPUT',output),\
                 patch.object(mod,'fetch_crossref',side_effect=RuntimeError('failure')),\
                 patch.object(mod,'fetch_arxiv',side_effect=RuntimeError('failure')),\
                 patch.object(mod,'fetch_rss',side_effect=RuntimeError('failure')):
                with self.assertRaises(RuntimeError):mod.main()
            self.assertEqual(output.read_text(),original)

if __name__=='__main__':unittest.main()
